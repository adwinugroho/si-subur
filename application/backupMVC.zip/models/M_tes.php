<?php
class M_tes extends CI_Model
{

  public function insert($namatabel, $created_at, $entry_id, $field2){
    $this->load->database();
      $res = $this->db->query("insert into `$namatabel` values('$created_at', $entry_id, $field2)");
			return $res;
    }

}

<?php
class Tes extends CI_Controller{
  var $API ="";
  function __construct(){
    parent::__construct();
    //$this->load->model('M_login');
  }

  function index(){
    $this->load->view('v_tes');
  }

  function create()
  {
    $url = 'https://thingspeak.com/channels/511007/field/2.json';
    $response = file_get_contents($url);
    $content = json_decode($response);
    $isi = $content->feeds;
    $isiarr = json_decode(json_encode($isi));

    $this->load->database();
    $this->load->Model('M_tes');
    foreach ($isi as $key) {
      $created_at = $key->created_at;
      $entry_id = $key->entry_id;
      $field2 = $key->field2;
      $namatabel = 'content';
      $insertcontent = $this->M_tes->insert($namatabel, $created_at, $entry_id, $field2);
    }
    if ($insertcontent) {
      redirect('Tes');
    }
  }


}

<!DOCTYPE html>
<html lang="en" >
<head>
  <meta charset="UTF-8">
  <title>Login SI SUBUR</title>
      <link rel="stylesheet" href="<?php echo base_url()?>assets/css/style.css">
</head>
<body>
  <div class="wrapper">
	<div class="container">
		<h1>Selamat Datang!</h1>
		<form class="form" method="post" action="<?php echo('Login/auth.php'); ?>">
			<input type="text" placeholder="Username" name="username">
			<input type="password" placeholder="Password" name="password">
			<button type="submit" id="login-button">Login</button>
		</form>
	</div>
	<ul class="bg-bubbles">
		<li></li>
		<li></li>
		<li></li>
		<li></li>
		<li></li>
		<li></li>
		<li></li>
		<li></li>
		<li></li>
		<li></li>
	</ul>
</div>
  <script src='http://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js'></script>
  <script  src="<?php echo base_url()?>assets/js/index.js"></script>
</body>
</html>

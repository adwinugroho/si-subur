<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title>Tes</title>
  </head>
  <body>
    <form action="<?php echo site_url('Tes/create');?>" method="post">
      <button type="submit" name="button">Submit</button>
    </form>
  </body>
</html>
